using Xunit;
using static System.Net.Mime.MediaTypeNames;
using simple;
namespace simple.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            var code = "LET s = 1 \n";
            AntlrInputStream inputStream = new AntlrInputStream(text.ToString());
            SimpleLexer

        }
    }
}