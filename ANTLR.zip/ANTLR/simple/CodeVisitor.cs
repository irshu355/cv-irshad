﻿using Antlr4.Runtime.Misc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simple
{

    public interface ICodeGenerator
    {
        string GenerateCode();
    }

    public class CSharpCodeGenerator : ICodeGenerator
    {
        private readonly DSLCodeSnippetSetup _snippetSetup;
        private StringBuilder _codeBuilder;
        public CSharpCodeGenerator(DSLCodeSnippetSetup snippetSetup)
        {
            this._snippetSetup = snippetSetup;
        }

        public string GenerateCode()
        {
            _codeBuilder = new StringBuilder();

            foreach (var line in _snippetSetup.Snippets)
            {
                _codeBuilder.Append(line.GenerateCode());
                _codeBuilder.Append("\r\n");
            }

            return _codeBuilder.ToString();
        }
    }

    public class CodeVisitor : SimpleLangBaseVisitor<ICodeSnippet>
    {
        private static readonly double SMALL_VALUE = 0.000000001;

        public List<ICodeSnippet> mem = new();

        StringBuilder _generatedCode = new StringBuilder();

        public override ICodeSnippet VisitParse([NotNull] SimpleLangParser.ParseContext context)
        {
            return base.VisitParse(context);
        }

        public override ICodeSnippet VisitBlock([NotNull] SimpleLangParser.BlockContext context)
        {
            List<ICodeSnippet> stats = new();
            foreach (var item in context.stat())
            {
                stats.Add(this.Visit(item));
            }
            return new BlockCodeSnippet(stats);
        }

        public override ICodeSnippet VisitAssignment([NotNull] SimpleLangParser.AssignmentContext context)
        {
            var var_name = context.ID().ToString();
            var value = this.Visit(context.expr());
            var assignSnippet = new AssignmentCodeSnippet(varName: var_name, value: value);
            if (context.Parent.Depth() == 3)
            {
                mem.Add(assignSnippet);
            }
            return assignSnippet;
        }

        public override ICodeSnippet VisitInitialize([NotNull] SimpleLangParser.InitializeContext context)
        {
            var var_name = context.ID().ToString();
            var value = this.Visit(context.expr());
            var initSnippet = new InitializationCodeSnippet(varName: var_name, value: value);
            mem.Add(initSnippet);
            return initSnippet;
        }

        public override ICodeSnippet VisitStringAtom([NotNull] SimpleLangParser.StringAtomContext context)
        {
            var str = context.STRING().ToString();
            return new StringValueSnippet(str);
        }

        public override ICodeSnippet VisitIdAtom([NotNull] SimpleLangParser.IdAtomContext context)
        {
            var str = context.ID().ToString();
            return new StringValueSnippet(str);
        }

        public override ICodeSnippet VisitEqualityExpr([NotNull] SimpleLangParser.EqualityExprContext context)
        {
            var left = this.Visit(context.expr()[0]);
            var right = this.Visit(context.expr()[1]);

            var snippet = new EqualityConditionSnippet(left, right, context.EQ() != null ? EqualityConditionSnippet.EQUAL : EqualityConditionSnippet.NOTEQUAL);
            return snippet;
        }

        public override ICodeSnippet VisitNumberAtom([NotNull] SimpleLangParser.NumberAtomContext context)
        {
            var str = context.INT() == null ? context.FLOAT().ToString() : context.INT().ToString();
            return new NumberValueSnippet(str);
        }

        public override ICodeSnippet VisitDomainSpecificFunc([NotNull] SimpleLangParser.DomainSpecificFuncContext context)
        {
            var func = context.domain_spec_func().func().GetText().ToString();

            var snippet = new DomainFuncSnippet(func);
            foreach (var atom in context.domain_spec_func().expr())
            {
                var arg = this.Visit(atom);
                snippet.addArgs(arg);
            };
            return snippet;
        }


        public override ICodeSnippet VisitIf_stat([NotNull] SimpleLangParser.If_statContext context)
        {
            //var snippet = new Snippet(SnippetOp.IF, new Value(context.));
            var parent = context.Parent;
            var condition = this.Visit(context.condition_block()[0]);
            var snippet = new IfStatementSnippet(condition);
            if (context.Parent.Depth() == 3)
            {
                mem.Add(snippet);
            }
            return snippet;
        }
        public override ICodeSnippet VisitCondition_block([NotNull] SimpleLangParser.Condition_blockContext context)
        {
            var expression = this.Visit(context.expr());
            var stat_block = this.Visit(context.stat_block());
            return new ConditionalBlockSnippet(expression, stat_block);
        }

        public override ICodeSnippet VisitStat_block([NotNull] SimpleLangParser.Stat_blockContext context)
        {
            return new ConditionalStatBlockSnippet(this.Visit(context.block()));
        }

    }

    public class DSLCodeSnippetSetup
    {
        /*
         * A wrapper class can also be named with Settings / Info suffixes
         */
        public List<ICodeSnippet> Snippets { get; set; }
        public string ParserLib { get; set; }

        public DSLCodeSnippetSetup(List<ICodeSnippet> mem, string v)
        {
            this.Snippets = mem;
            this.ParserLib = v;
        }

    }




    public interface ICodeSnippet
    {
        string GenerateCode();
    }

    public abstract class CodeSnippetBase : ICodeSnippet
    {
        protected StringBuilder _codeBuilder = new();
        public abstract string GenerateCode();

    }


    public class InitializationCodeSnippet : CodeSnippetBase
    {
        private string _varName;
        private ICodeSnippet _value;

        public InitializationCodeSnippet(string varName, ICodeSnippet value)
        {
            this._varName = varName;
            _value = value;
        }

        public override string GenerateCode() => $"var {_varName} = {_value.GenerateCode()};";
        
    }

    public class BlockCodeSnippet : CodeSnippetBase
    {
        private List<ICodeSnippet> _statements = new();
        public BlockCodeSnippet(List<ICodeSnippet> statements)
        {
            _statements = statements;
        }
        public override string GenerateCode()
        {
            foreach (var item in _statements)
            {
                _codeBuilder.Append(item.GenerateCode());
            }
            return _codeBuilder.ToString();
        }
    }

    public class AssignmentCodeSnippet : CodeSnippetBase
    {
        private string _varName;
        private ICodeSnippet _value;

        public AssignmentCodeSnippet(string varName, ICodeSnippet value)
        {
            this._varName = varName;
            _value = value;
        }

        public override string GenerateCode() => $"{_varName} = {_value.GenerateCode()};";
    }


    public class StringValueSnippet : CodeSnippetBase
    {
        private string _str;

        public StringValueSnippet(string str)
        {
            this._str = str;
        }

        public override string GenerateCode() => this._str;
    }

    public class NumberValueSnippet : CodeSnippetBase
    {
        private string _number;

        public NumberValueSnippet(string number)
        {
            this._number = number;
        }

        public override string GenerateCode() => _number;
    }

    public class DomainFuncSnippet : CodeSnippetBase
    {
        private string _funcName;
        private List<ICodeSnippet> _args = new();

        public DomainFuncSnippet(string funcName)
        {
            this._funcName = funcName;
        }

        public void addArgs(ICodeSnippet arg)
        {
            this._args.Add(arg);
        }

        public override string GenerateCode()
        {
            _codeBuilder.Append(_funcName).Append("(");
            if (_args.Any())
            {
                foreach (var arg in _args)
                {
                    _codeBuilder.Append(arg.GenerateCode()).Append(",");
                }
                _codeBuilder.Remove(_codeBuilder.Length - 1, 1);
            }
            _codeBuilder.Append(")");
            return _codeBuilder.ToString();
        }
    }


    public class IfStatementSnippet : CodeSnippetBase
    {
        private List<ICodeSnippet> Else_conditions = new();
        private ICodeSnippet _ifCondition;
        public IfStatementSnippet(ICodeSnippet condition)
        {
            this._ifCondition = condition;
        }
        public override string GenerateCode()
        {
            return $"if {this._ifCondition.GenerateCode()}";
        }

    }

    public class ConditionalBlockSnippet : CodeSnippetBase
    {
        private ICodeSnippet _expression;
        private ICodeSnippet _stat_block;

        public ConditionalBlockSnippet(ICodeSnippet expression, ICodeSnippet stat_block)
        {
            this._expression = expression;
            this._stat_block = stat_block;
        }

        public override string GenerateCode()
        {
            return $"( {_expression.GenerateCode()} ) {this._stat_block.GenerateCode()} ";
        }

    }

    public class ConditionalStatBlockSnippet : CodeSnippetBase
    {
        private ICodeSnippet _blockSnippet;

        public ConditionalStatBlockSnippet(ICodeSnippet _blockSnippet)
        {
            this._blockSnippet = _blockSnippet;
        }

        public override string GenerateCode()
        {
            _codeBuilder.Append(" { ").Append(_blockSnippet.GenerateCode()).Append("}");
            return _codeBuilder.ToString();
        }

    }


    /*
    equality expressions
     */


    public class EqualityConditionSnippet : CodeSnippetBase
    {
        private ICodeSnippet _left;
        private ICodeSnippet _right;

        public static int EQUAL = 0;
        public static int NOTEQUAL = 1;
        private int mode;

        public EqualityConditionSnippet(ICodeSnippet left, ICodeSnippet right, int mode)
        {
            _left = left;
            _right = right;
            this.mode = mode;
        }


        public override string GenerateCode()
        {
            _codeBuilder.Append(_left.GenerateCode()).Append(mode == EQUAL ? " == " : " != ").Append(_right.GenerateCode());
            return _codeBuilder.ToString();
        }
    }
}
