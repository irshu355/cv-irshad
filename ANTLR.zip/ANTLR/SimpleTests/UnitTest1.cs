using Antlr4.Runtime;
using Antlr4.Runtime.Tree;
using Simple;
using System.Runtime.CompilerServices;

namespace SimpleTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            //var code = "LET Name=\"Irshu\"";
            //var chars = new AntlrInputStream(code);
            //var lexer = new SimpleLexer(chars);
            //var tokens = new CommonTokenStream(lexer);
            //var parser = new SimpleParser(tokens);

            //var tree = parser.program();
            //var listener = new SimpleDeclareListener();
            //ParseTreeWalker.Default.Walk(listener, tree);

        }

        [Fact]
        public void Test2()
        {
            var init = "let addr = GetAddr(GetName(100)) ; addr = \"irshu\" ; let num = 10 ; if num == 10 { num = 11; }";
            var chars = new AntlrInputStream(init);
            var lexer = new SimpleLangLexer(chars);
            var tokens = new CommonTokenStream(lexer);
            var parser = new SimpleLangParser(tokens);
            var parseTree = parser.parse();
            CodeVisitor visitor = new CodeVisitor();
            visitor.Visit(parseTree);

            var snippetInfo = new DSLCodeSnippetSetup(visitor.mem, "Antlr4.v4");
            var genertor = new CSharpCodeGenerator(snippetInfo);
            var code = genertor.GenerateCode();

            Assert.True(!string.IsNullOrEmpty(code));
        }
    }
}